import java.util.Date;

public class Home extends Insurable {
    private Date buildDate;
    private String heating;
    private boolean urban;
    private Address address;

    public Home(float value, Date buildDate, String heating, boolean urban, Address address) {
        super(value);
        this.buildDate = buildDate;
        this.heating = heating;
        this.urban = urban;
        this.address = address;
    }

    public Date getBuildDate() {
        return buildDate;
    }

    public void setBuildDate(Date buildDate) {
        this.buildDate = buildDate;
    }

    public String getHeating() {
        return heating;
    }

    public void setHeating(String heating) {
        this.heating = heating;
    }

    public boolean isUrban() {
        return urban;
    }

    public void setUrban(boolean urban) {
        this.urban = urban;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}

