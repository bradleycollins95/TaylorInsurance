public class Customer extends Person {
    private int customerId;
    private String username;
    private String password;
    //private ArrayList<InsuredItem> insuredItems;

    public Customer(String firstName, String lastName, int age, String phoneNumber, String email, String address,
                    int customerId, String username, String password) {
        super(firstName, lastName, age, phoneNumber, email, address);
        this.customerId = customerId;
        this.username = username;
        this.password = password;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public void showCustomerInfo() {
        System.out.println("Customer details: " +
                            "\nCustomer ID: " + getCustomerId() +
                            "\nFirst name: " + getFirstName() +
                            "\nLast name: " + getLastName() +
                            "\nAge: " + getAge() +
                            "\nAddress: " + getAddress() +
                            "\nPhone number: " + getPhoneNumber() +
                            "\nEmail address: " + getEmail());
    }

    public void showLoginDetails() {
        System.out.println("Login details: " +
                            "\nUsername: " + getUsername() +
                            "\nPassword: " + getPassword());
    }

    public boolean verifyLogin(String username, String password) {
        // consider hashing instead of storing plain text
        return this.username.equals(username) && this.password.equals(password);
    }
}
