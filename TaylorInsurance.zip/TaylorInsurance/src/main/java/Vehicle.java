public class Vehicle extends Insurable {
    private String make;
    private String model;
    private int year;
    private int accidents;

    public Vehicle(float value, String make, String model, int year, int accidents) {
        super(value);
        this.make = make;
        this.model = model;
        this.year = year;
        this.accidents = accidents;
    }

    // Getters and Setters
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getAccidents() {
        return accidents;
    }

    public void setAccidents(int accidents) {
        this.accidents = accidents;
    }
}

