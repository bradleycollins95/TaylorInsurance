import java.util.Date;

public class Policy {
    private int policyId;
    private Date effectiveDate;
    private String policyType;
    private Quote quote;
    private float premium;
    private boolean isActive;

    public Policy(int policyId, Date effectiveDate, String policyType, Quote quote, float premium, boolean isActive) {
        this.policyId = policyId;
        this.effectiveDate = effectiveDate;
        this.policyType = policyType;
        this.quote = quote;
        this.premium = premium;
        this.isActive = isActive;
    }

    public int getPolicyId() {
        return policyId;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public String getPolicyType() {
        return policyType;
    }

    public Quote getQuote() {
        return quote;
    }

    public float getPremium() {
        return premium;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean status) {
        isActive = status;
    }
}
