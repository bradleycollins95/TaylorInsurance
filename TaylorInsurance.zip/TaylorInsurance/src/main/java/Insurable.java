import java.util.ArrayList;
import java.util.List;

public abstract class Insurable {
    private List<Quote> quotes;
    private List<Policy> policies;
    private float value;

    public Insurable(float value) {
        this.value = value;
        this.quotes = new ArrayList<>();
        this.policies = new ArrayList<>();
    }

    public List<Quote> getQuotes() {
        return quotes;
    }

    public void setQuotes(List<Quote> quotes) {
        this.quotes = quotes;
    }

    public List<Policy> getPolicies() {
        return policies;
    }

    public void setPolicies(List<Policy> policies) {
        this.policies = policies;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public void addQuote(Quote quote) {
        quotes.add(quote);
    }

    public void addPolicy(Policy policy) {
        policies.add(policy);
    }
}

