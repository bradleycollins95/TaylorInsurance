import java.util.Date;

public class Quote {
    private int quoteId;
    private Date generationDate;
    private String quoteType;
    private float basePremium;
    private boolean isActive;

    public Quote(int quoteId, Date generationDate, String quoteType, float basePremium, boolean isActive) {
        this.quoteId = quoteId;
        this.generationDate = generationDate;
        this.quoteType = quoteType;
        this.basePremium = basePremium;
        this.isActive = isActive;
    }

    public int getQuoteId() {
        return quoteId;
    }

    public Date getGenerationDate() {
        return generationDate;
    }

    public String getQuoteType() {
        return quoteType;
    }

    public float getBasePremium() {
        return basePremium;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean status) {
        this.isActive = status;
    }
}
